package com.example.Surajbookstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SurajbookstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
